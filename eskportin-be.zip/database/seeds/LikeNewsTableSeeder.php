<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class LikeNewsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('like_news')->delete();
        
        
        
    }
}