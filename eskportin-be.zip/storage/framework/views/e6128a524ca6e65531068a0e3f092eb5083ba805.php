<?php echo e($slot); ?>

<?php /**PATH D:\kuliah\TA\eskportin-be\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>