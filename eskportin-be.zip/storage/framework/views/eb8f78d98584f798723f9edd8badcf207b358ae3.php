<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\kuliah\TA\eskportin-be\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>